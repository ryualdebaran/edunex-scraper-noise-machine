from flask import Flask, jsonify
import json
import os
import subprocess

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
JSON_FILE = os.path.join(BASE_DIR, "output.json")
MAIN_FILE = os.path.join(BASE_DIR, "Main.py")

@app.route('/data', methods=['GET'])
def get_data():
    # Jalankan Main.py dulu untuk update output.json
    subprocess.run(["py", "-3.12", MAIN_FILE], cwd=BASE_DIR)

    if not os.path.exists(JSON_FILE):
        return jsonify({"error": "File not found"}), 404

    with open(JSON_FILE, 'r') as f:
        data = json.load(f)

    return jsonify(data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)